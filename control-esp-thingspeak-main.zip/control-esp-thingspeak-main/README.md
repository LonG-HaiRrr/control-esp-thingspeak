# control-esp-thingspeak
This interface supports reading and controlling LEDs, monitoring temperature, and maybe can send some notifications through ThingSpeak.


if you want to use for your project, you will must change about: 
my Channel ID: 3010385
write : JZTKGG4S7ELIOD15
read : JOOY7F6GQUPDVQRC
picture day/night 